﻿/*-----------------------------------------------------------------------------
　スクリプト要約 :  マップ内のNPCをインタラクトした際の会話用
-----------------------------------------------------------------------------*/

using UdonSharp;
using UnityEngine;
using TMPro;
using VRC.SDKBase;
using VRC.Udon;

public class SpeechBubbleTextSwitcher : UdonSharpBehaviour
{
    [TextArea]
    public string[] lines; //アタッチするNPCに応じてセリフ数を変更

    public GameObject speechBubble;     // 吹き出しオブジェクト（ON/OFF）
    public TextMeshPro textMesh;        // 吹き出し内のセリフ変更用

    private int index = 0;  //セリフ数の管理
    private bool isPlaying = false; //会話中か否かを判定

    void Start()
    {
        //初期リセット
        if (speechBubble != null)
            speechBubble.SetActive(false);
    }

    public override void Interact()
    {
        //NPC押下時に会話が始まっている場合は、次のセリフを出す。始まっていない場合は最初のセリフを出す
        if (isPlaying)
        {
            NextSpeech();
        }
        else
        {
            StartSpeech();
        }
    }

    //最初のセリフ
    private void StartSpeech()
    {
        //何も設定していない場合、動作なし
        if (lines.Length == 0 || textMesh == null || speechBubble == null)
            return;

        //セリフ・吹き出し表示,indexでセリフ数管理
        speechBubble.SetActive(true);
        index = 0;
        textMesh.text = lines[0];
        isPlaying = true;
    }

    //続きのセリフ
    private void NextSpeech()
    {
        index++;

        if (index >= lines.Length)
        {
            EndSpeech(); // 最後のセリフで終了へ
        }
        else
        {
            //textmeshproを変更する形でセリフを表示する
            textMesh.text = lines[index];
        }
    }

    //会話終了、セリフ・吹き出し非表示
    private void EndSpeech()
    {
        isPlaying = false;
        index = 0;
        if (speechBubble != null)
            speechBubble.SetActive(false);
    }
}
