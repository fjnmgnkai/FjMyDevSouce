﻿/*-----------------------------------------------------------------------------
　スクリプト要約 :  プレイヤーを花火として打ち上げるスクリプト
-----------------------------------------------------------------------------*/

using UdonSharp;
using UnityEngine;
using VRC.SDKBase;
using VRC.Udon;

public class FireworkLauncher : UdonSharpBehaviour
{
    public VRCStation fireworkStation; //プレイヤーのsit用
    public AudioSource countdownAudio; //打ち上げカウントダウン音声
    public ParticleSystem fireworkEffect; //花火エフェクト
    public float countdownDuration = 3f; //打ち上げ発射までの時間
    public float launchForce = 20f; //打ち上げ速度
    public float fireworkDelay = 2f; //花火再生までの時間

    private bool isLaunching = false; //カウントダウン中かの判定用
    private float timer = 0f; //カウントダウンタイマー
    private VRCPlayerApi localPlayer; //インタラクトしたプレイヤー取得

    private bool isFireworkPending = false; //花火再生中か否かのフラグ
    private float fireworkTimer = 0f; //遅延時間用タイマー
    private Vector3 launchDirection; //打ち上げ方向

    private float immobileTimer = 0f; //打ち上げ後の行動不能時間
    private bool isImmobile = false; //行動不能かの判定

    //打ち上げ装置をインタラクトした際のメソッド
    public override void Interact()
    {
        if (isLaunching || isFireworkPending) return;

        //インタラクトしたプレイヤーを取得
        localPlayer = Networking.LocalPlayer;
        if (localPlayer == null) return;

        // オーナーを操作プレイヤーに設定、ネットワーク同期用
        Networking.SetOwner(localPlayer, gameObject);

        //打ち上げ装置にプレイヤーをセットする
        fireworkStation.UseStation(localPlayer);
        StartCountdown();

        //プレイヤーの動作固定
        localPlayer.Immobilize(true);
        immobileTimer = 10f;
        isImmobile = true;
    }

    //プレイヤーのsit時カウントダウンの開始
    private void StartCountdown()
    {
        isLaunching = true;
        timer = countdownDuration;

        if (countdownAudio != null)
            countdownAudio.Play();
    }

    private void Update()
    {
        //発射中でなければ発射
        if (isLaunching)
        {
            timer -= Time.deltaTime;
            if (timer <= 0f)
            {
                LaunchPlayer();
                isLaunching = false;
            }
        }

        if (isFireworkPending)
        {
            fireworkTimer -= Time.deltaTime;
            if (fireworkTimer <= 0f)
            {
                // 全プレイヤーに対して花火を再生
                SendCustomNetworkEvent(VRC.Udon.Common.Interfaces.NetworkEventTarget.All, "PlayFireworkEffect");
                isFireworkPending = false;
            }
        }

        //行動不能の解除
        //発射後⇒プレイヤーの位置取得⇒エフェクト同期再生ができなかったので、行動不能にして特定位置にプレイヤーが来るようにした
        if (isImmobile)
        {
            immobileTimer -= Time.deltaTime;
            if (immobileTimer <= 0f && localPlayer != null)
            {
                localPlayer.Immobilize(false);
                isImmobile = false;
            }
        }
    }

    private void LaunchPlayer()
    {
        //プレイヤーをstationから解放⇒setvelocityで吹き飛ばす⇒移動制限
        if (localPlayer == null) return;

        fireworkStation.ExitStation(localPlayer);

        launchDirection = (transform.forward * 0.3f + transform.up).normalized;
        localPlayer.SetVelocity(launchDirection * launchForce);

        localPlayer.Immobilize(true);
        immobileTimer = 10f;
        isImmobile = true;

        fireworkTimer = fireworkDelay;
        isFireworkPending = true;
    }

    //花火エフェクト再生用
    public void PlayFireworkEffect()
    {
        if (fireworkEffect != null)
            fireworkEffect.Play();
    }
}
