﻿/*-----------------------------------------------------------------------------
　スクリプト要約 :  パスワード入力後に取得できるアイテム・ロジック
-----------------------------------------------------------------------------*/

using UdonSharp;
using UnityEngine;
using TMPro;

public class picturePass : UdonSharpBehaviour
{
    public string correctPassword = ""; //正解のパスワード
    public TMP_InputField passwordInput; //パスワード入力用UI
    public GameObject targetObject1; //正解で入手できるアイテム
    public AudioSource correctSound; //正解音
    public AudioSource incorrectSound; //不正解音

    void Start()
    {
        // 入手アイテム非表示
        targetObject1.SetActive(false);
    }

    //パスワードチェック用, inputfieldに入力⇒正解であれば、アイテム入手
    public void CheckPassword()
    {
        string inputPassword = passwordInput.text;

        //入力ナシなら処理飛ばす
        if (string.IsNullOrWhiteSpace(inputPassword))
        {
            return;
        }

        if (inputPassword == correctPassword)
        {
            // パスワード正解でオブジェクト表示
            targetObject1.SetActive(true);
            PlaySound(correctSound);
        }
        else if (inputPassword != correctPassword)
        {
            PlaySound(incorrectSound);
        }

        // 入力フィールドをクリア
        passwordInput.text = "";
    }

    //正解・不正解音再生
    private void PlaySound(AudioSource source)
    {
        if (source != null)
        {
            source.Play();
        }
    }

}
