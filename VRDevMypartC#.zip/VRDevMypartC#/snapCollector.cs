﻿/*-----------------------------------------------------------------------------
　スクリプト要約 :  一定数のオブジェクトを集めた際に、1つに統合する
-----------------------------------------------------------------------------*/
using UdonSharp;
using UnityEngine;
using VRC.SDKBase;
using VRC.Udon;

public class snapCollector : UdonSharpBehaviour
{
    public Transform[] snapTargets;       // 吸着位置
    public GameObject[] objectsToTrack;   // 対象のオブジェクト
    public GameObject finalResultObject;  // 最終出現オブジェクト

    private bool[] isSnapped; //連続吸着防止用
    private int snappedCount = 0; //一定数
    private bool isCompleted = false; //完了後の再処理防止用

    void Start()
    {
        //初期リセット
        if (finalResultObject != null) finalResultObject.SetActive(false);
        isSnapped = new bool[objectsToTrack.Length];
    }

    public void OnTriggerEnter(Collider other)
    {
        if (isCompleted) return;

        GameObject obj = other.gameObject; //範囲に入ったオブジェクトを判定する。

        // 吸着対象かを判定する
        for (int i = 0; i < objectsToTrack.Length; i++)
        {
            if (objectsToTrack[i] == obj && !isSnapped[i])
            {
                SnapObject(obj, i);
                break; //returnでは同じオブジェクトが何度も吸着されるため、breakに変更
            }
        }
    }

    //オブジェクトを吸着する処理
    private void SnapObject(GameObject obj, int index)
    {
        // すでに吸着済みかをチェック（念のため）
        if (isSnapped[index]) return;

        isSnapped[index] = true;

        // pickupを無効化して吸着済みオブジェクトを拾えないようにする
        VRC_Pickup pickup = obj.GetComponent<VRC_Pickup>();
        if (pickup != null)
        {
            pickup.Drop();                // 持っている場合Drop
            pickup.pickupable = false;    // 拾えないようにする
            Destroy(pickup);              // pickupコンポーネントを削除
        }

        // Rigidbody固定
        Rigidbody rb = obj.GetComponent<Rigidbody>();
        if (rb != null)
        {
            rb.velocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;
            rb.isKinematic = true;
            rb.useGravity = false;
            rb.constraints = RigidbodyConstraints.FreezeAll; // 完全固定
        }

        // 位置・回転スナップ
        obj.transform.position = snapTargets[index].position;
        obj.transform.rotation = snapTargets[index].rotation;

        snappedCount++;

        if (snappedCount >= objectsToTrack.Length)
        {
            CompleteSnap();
        }
    }

    private void CompleteSnap()
    {
        isCompleted = true;

        //Debug.Log("処理開始");
        SendCustomEventDelayedSeconds("DoCompleteSnap", 0.1f);
    }

    //全てそろった後に表示・非表示を切り替える
    public void DoCompleteSnap()
    {
        //Debug.Log("オブジェクト表示・非表示処理開始");

        // 12個のPickupを全部非表示に
        for (int i = 0; i < objectsToTrack.Length; i++)
        {
            if (objectsToTrack[i] != null)
            {
                objectsToTrack[i].SetActive(false);
                //Debug.Log($"オブジェクト{i}を非表示");
            }
        }

        // 最終オブジェクトを表示
        if (finalResultObject != null)
        {
            finalResultObject.SetActive(true);
            //Debug.Log("最終オブジェクト表示");
        }
        else
        {
            //Debug.LogError("対象が存在しません");
        }
    }
}